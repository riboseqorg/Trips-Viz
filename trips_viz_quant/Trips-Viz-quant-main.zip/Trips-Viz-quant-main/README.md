Trips-Viz with quantification functionality. 

Copy the annotation and shelve folders to the directory containing __init__.py and config.py files 
https://drive.google.com/drive/folders/11OirlO6ugDnKGLX0e5cSnNqhWTUbARli?usp=sharing

Compared to current github version of trips this is ready to be deployed as a local version. SCRIPT_LOC is determined using os packages and file names have been changed as specified. 

Run the __init__.py script with python 2 and navigate to 0.0.0.0:5000/ in a browser (if running on a server replace 0.0.0.0 with the server IP). 
